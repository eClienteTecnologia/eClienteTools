// let mais = document.getElementById('aumentaQuantidade');
// let menos = document.getElementById('diminuirQuantidade');
// let input = document.getElementById('demo3');
// let valor = input.value;


// mais.addEventListener('click', function mais(){
//     valor ++;
//     input.value = valor;
// })

// menos.addEventListener('click', function menos(){
//     valor --;
//     input.value = valor
// })